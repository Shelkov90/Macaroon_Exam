import React, { PureComponent } from 'react'

class Newspage extends PureComponent {
	constructor(props) {
		super(props)

		this.state = {
			
		}
	}

	render() {
		return (
			<div></div>
		)
	}
}

export default Newspage