import React, { PureComponent } from 'react'

class Sweet extends PureComponent {
	constructor(props) {
		super(props)

		this.state = {
			
		}
	}

	render() {
		return (
			<>
			Sweet
			</>
		)
	}
}

export default Sweet