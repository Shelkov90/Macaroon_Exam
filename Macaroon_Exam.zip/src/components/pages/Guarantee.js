import React, { PureComponent } from 'react'

class Guarantee extends PureComponent {
	constructor(props) {
		super(props)

		this.state = {
			
		}
	}

	render() {
		return (
			<>
			Guarantee
			</>
		)
	}
}

export default Guarantee