import React, { PureComponent } from 'react'

class Contacts extends PureComponent {
	constructor(props) {
		super(props)

		this.state = {
			
		}
	}

	render() {
		return (
			<>
			Contacts
			</>
		)
	}
}

export default Contacts