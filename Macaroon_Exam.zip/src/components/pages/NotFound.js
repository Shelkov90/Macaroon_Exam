import React, { PureComponent } from 'react'

class NotFound extends PureComponent {
	constructor(props) {
		super(props)

		this.state = {
			
		}
	}

	render() {
		return (
			<>
			NotFound
			</>
		)
	}
}

export default NotFound