import React, { PureComponent } from 'react'

class Catalogue extends PureComponent {
	constructor(props) {
		super(props)

		this.state = {
			
		}
	}

	render() {
		return (
			<>
			Catalogue
			</>
		)
	}
}

export default Catalogue